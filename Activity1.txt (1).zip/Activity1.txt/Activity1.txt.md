# Activity1.txt  
  
Klint Filip A. Ingente   
Klint Filip A. Ingente  
Klint Filip A. Ingente   
Klint Filip A. Ingente   
Klint Filip A. Ingente   
Klint Filip A. Ingente   
Klint Filip A. Ingente  
Klint Filip A. Ingente   
Klint Filip A. Ingente   
Klint Filip A. Ingente   
  
Bachelor of Science in Information Technology   
Bachelor of Science in Information Technology  
Bachelor of Science in Information Technology   
Bachelor of Science in Information Technology   
Bachelor of Science in Information Technology  
Bachelor of Science in Information Technology  
 Bachelor of Science in Information Technology   
Bachelor of Science in Information Technology  
Bachelor of Science in Information Technology  
Bachelor of Science in Information Technology  
